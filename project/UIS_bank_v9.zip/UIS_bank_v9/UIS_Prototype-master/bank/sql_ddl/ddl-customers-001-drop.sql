/*
* Bank project
*
*/

ALTER TABLE customers
DROP COLUMN "direct"
;

-- SELECT * FROM customers order by 5;
-- COMMIT;

